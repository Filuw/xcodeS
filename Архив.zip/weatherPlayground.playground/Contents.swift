import UIKit

func weatherData(){
    let urlString = "https://api.weatherapi.com/v1/current.json?key=5f09457003cf46f780d12915221203&q=London&aqi=no"
    
    let url = URL(string: urlString)
    
    let session = URLSession(configuration: .default)
    
    let task = session.dataTask(with: url!) { (data, response, error) in
        if let data = data{
            let dataString = String(data: data, encoding: .utf8)
            print(dataString!)
        }
    }
    task.resume()
}
weatherData()

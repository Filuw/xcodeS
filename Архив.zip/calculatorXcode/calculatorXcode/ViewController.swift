//
//  ViewController.swift
//  calculatorXcode
//
//  Created by Семенова Слепцова ИСИП 20 on 02.03.2022.
//

import UIKit
class ViewController: UIViewController {
    
    @IBOutlet weak var buttonAC: UIButton!
    @IBOutlet weak var buttonZero: UIButton!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var buttonChangeResultLabel: UIStepper!
    
    var numberOne = ""
    var numberTwo = ""
    var operand = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        buttonAC.layer.contents = 36
    }
    
    
    @IBAction func inputNumber(_ sender: UIButton) {
        if operand.isEmpty{
            numberOne = numberOne +
                (sender.titleLabel?.text)!
        }
    }
    
}

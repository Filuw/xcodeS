//
//  ViewController.swift
//  weatherApp
//
//  Created by Семенова Слепцова ИСИП 20 on 12.03.2022.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var cityName: UILabel!
    @IBOutlet var cityTemp: UILabel!
    @IBOutlet var day: UILabel!
    @IBOutlet var h: UILabel!
    @IBOutlet var w: UILabel!
    @IBOutlet var text: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let urlString = "https://api.weatherapi.com/v1/current.json?key=5f09457003cf46f780d12915221203&q=Yakutsk&aqi=no"
        
        let url = URL(string: urlString)
        
        let session = URLSession(configuration: .default)
        
        let task = session.dataTask(with: url!) { (data, response, error) in
            if let data = data{
                self.parseJSON(withData: data)
                /*let dataString = String(data: data, encoding: .utf8)
                print(dataString!)*/
            }
        }
        task.resume()
    }
    func parseJSON(withData data: Data){
        let decoder = JSONDecoder()
        do{
            let apiItem = try decoder.decode(Welcome.self, from: data)
            
            cityName.text = apiItem.location.name
            cityTemp.text = String(apiItem.current.tempC)
            day.text = String(apiItem.current.lastUpdated)
            h.text = String(apiItem.current.windMph)
            w.text = String(apiItem.current.windKph)
            text.text = String(apiItem.current.condition.text)
        
        }
        catch let error as NSError{
            print(error.localizedDescription)
        }
    }

}


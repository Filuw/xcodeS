//
//  secure.swift
//  weatherApp
//
//  Created by Семенова Слепцова ИСИП 20 on 12.03.2022.
//

import Foundation

let apiKey="5f09457003cf46f780d12915221203"

//
//  DitailInterfaceController.swift
//  MyCookApp
//
//  Created by Семенова Слепцова ИСИП 20 on 06.04.2022.
//

import WatchKit

class DitailInterfaceController: NSObject {
    
    @IBOutlet weak var iconLable: WKInterfaceLabel!
    @IBOutlet weak var nameLable: WKInterfaceLabel!
    @IBOutlet weak var recipeImage: WKInterfaceImage!
    @IBOutlet weak var recipeTitleLable: WKInterfaceLabel!
}
